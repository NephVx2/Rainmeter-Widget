Hello
Drag this folder into your Rainmeter skins folder.

Font is Bitdust One found here:
http://www.dafont.com/bitdust-one.font

-BGBW